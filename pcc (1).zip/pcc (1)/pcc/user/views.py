from django.shortcuts import render, redirect, reverse
from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth.decorators import login_required
from django.urls import reverse_lazy
from django.views import generic
from usuario.models import Usuario
from ONG.models import ONG

class Cadastrar(generic.CreateView):
    form_class = UserCreationForm
    template_name = 'Cadastrar.html'
    success_url = reverse_lazy('login')

@login_required
def Home(request):
    u = request.user
    ong = ONG.objects.filter(user=u)
    usuario =Usuario.objects.filter(user=u)
    if usuario:
        return redirect('/animais/listar/')
    elif ong:
        return redirect('/animais/')
    else:
        return redirect('/accounts/tipo_de_cadastro/')

@login_required
def TipoCadastro(request):
    return render(request, 'TipoCadastro.html')