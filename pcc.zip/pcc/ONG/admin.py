from django.contrib import admin
from .models import ONG

admin.site.register(ONG)
# Register your models here.
